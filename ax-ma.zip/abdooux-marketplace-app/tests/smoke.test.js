'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
test('deployment files exist and enforce required secrets', () => {
  const root = path.join(__dirname, '..');
  const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
  assert.match(server, /app\.set\('trust proxy', 1\)/);
  assert.match(server, /SESSION_SECRET is required/);
  assert.match(server, /ADMIN_USERNAME is required/);
  assert.match(server, /app\.get\('\/healthz'/);
});
test('package scripts use Node env-file for local .env', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8'));
  assert.equal(pkg.scripts.start, 'node server.js');
  assert.match(pkg.scripts['start:local'], /--env-file=\.env/);
  assert.match(pkg.scripts['start:enzonic'], /node server\.js/);
});
