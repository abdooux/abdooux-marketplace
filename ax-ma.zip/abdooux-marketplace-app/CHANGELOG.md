# Changelog

## 1.2.0 — 2026-11-21
- Required stable admin credentials and session secret at startup.
- Added proxy awareness, SQLite-backed sessions, CSRF origin checks and rate limits.
- Added SQLite migrations, order events, audit records and backups.
- Improved WhatsApp validation, tracking code entropy and order validation.
- Added editable logo, billing period, icon and sort order controls.
- Added privacy, terms and cancellation/refund pages.
- Improved dynamic plan rendering, tracking timeline and date formatting.
