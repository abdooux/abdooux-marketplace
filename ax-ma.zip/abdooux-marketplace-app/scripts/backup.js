'use strict';
const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const dbFile = path.resolve(process.env.DB_FILE || path.join(__dirname, '..', 'data', 'marketplace.sqlite'));
const dir = path.join(path.dirname(dbFile), 'backups');
if (!fs.existsSync(dbFile)) throw new Error(`Database not found: ${dbFile}`);
fs.mkdirSync(dir, { recursive: true });
const db = new Database(dbFile, { readonly: true, fileMustExist: true });
const dest = path.join(dir, `marketplace-${new Date().toISOString().replace(/[:.]/g, '-')}.sqlite`);
db.backup(dest).then(() => {
  db.close();
  const files = fs.readdirSync(dir).filter(x => x.endsWith('.sqlite')).sort().reverse();
  for (const old of files.slice(10)) fs.unlinkSync(path.join(dir, old));
  console.log(`Backup created: ${dest}`);
}).catch(error => { db.close(); console.error(error); process.exitCode = 1; });
