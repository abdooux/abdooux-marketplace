'use strict';

const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const session = require('express-session');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);

const PORT = Number(process.env.PORT || 3000);
const NODE_ENV = process.env.NODE_ENV || 'development';
const IS_PROD = NODE_ENV === 'production';
const ADMIN_USERNAME = String(process.env.ADMIN_USERNAME || '').trim();
const ADMIN_PASSWORD = String(process.env.ADMIN_PASSWORD || '');
const SESSION_SECRET = String(process.env.SESSION_SECRET || '');
const DB_FILE = path.resolve(process.env.DB_FILE || path.join(__dirname, 'data', 'marketplace.sqlite'));
const DATA_DIR = path.dirname(DB_FILE);

function startupCheck() {
  if (!ADMIN_USERNAME) throw new Error('ADMIN_USERNAME is required. Set it in your environment.');
  if (ADMIN_USERNAME.length < 3 || ADMIN_USERNAME.length > 80) throw new Error('ADMIN_USERNAME must be 3–80 characters.');
  if (ADMIN_PASSWORD.length < 12) throw new Error('ADMIN_PASSWORD must contain at least 12 characters.');
  if (SESSION_SECRET.length < 32) throw new Error('SESSION_SECRET is required and must contain at least 32 characters.');
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.accessSync(DATA_DIR, fs.constants.W_OK);
  if (IS_PROD && process.env.DATA_DIR_PERSISTENT !== 'true') {
    console.warn('[storage] Confirm that the Enzonic data directory is mounted on persistent storage. Set DATA_DIR_PERSISTENT=true only after verifying this.');
  }
}

try { startupCheck(); } catch (error) { console.error(`[startup] ${error.message}`); process.exit(1); }

const db = new Database(DB_FILE);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

// Versioned, additive migrations preserve existing marketplace data.
const migrations = [
  {
    version: 1,
    sql: `
      CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
      );
      CREATE TABLE IF NOT EXISTS site_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, name TEXT NOT NULL,
        price TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', features TEXT NOT NULL DEFAULT '',
        visible INTEGER NOT NULL DEFAULT 1, featured INTEGER NOT NULL DEFAULT 0,
        sort_order INTEGER NOT NULL DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT '', icon TEXT NOT NULL DEFAULT '✦',
        visible INTEGER NOT NULL DEFAULT 1, sort_order INTEGER NOT NULL DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT, tracking_code TEXT NOT NULL UNIQUE,
        category TEXT NOT NULL, category_name TEXT NOT NULL, plan TEXT NOT NULL, price TEXT NOT NULL,
        customer_name TEXT NOT NULL, account_link TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'received' CHECK(status IN ('received','processing','completed','cancelled')),
        admin_note TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
        updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
      );
      CREATE TABLE IF NOT EXISTS sessions (
        sid TEXT PRIMARY KEY, sess TEXT NOT NULL, expired INTEGER NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_sessions_expired ON sessions(expired);
    `
  },
  {
    version: 2,
    sql: `
      CREATE TABLE IF NOT EXISTS order_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL,
        from_status TEXT, to_status TEXT NOT NULL, actor TEXT NOT NULL DEFAULT 'system',
        note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
        FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE
      );
      CREATE TABLE IF NOT EXISTS admin_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT, admin_id INTEGER, action TEXT NOT NULL,
        entity_type TEXT NOT NULL, entity_id TEXT, created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
      );
      CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
      CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at);
      CREATE INDEX IF NOT EXISTS idx_products_category_visible_sort ON products(category,visible,sort_order);
    `
  },
  {
    version: 3,
    sql: `
      ALTER TABLE orders ADD COLUMN customer_contact TEXT NOT NULL DEFAULT '';
      ALTER TABLE orders ADD COLUMN contact_channel TEXT NOT NULL DEFAULT '';
      ALTER TABLE orders ADD COLUMN customer_message TEXT NOT NULL DEFAULT '';
      ALTER TABLE orders ADD COLUMN price_amount INTEGER;
      ALTER TABLE orders ADD COLUMN currency TEXT NOT NULL DEFAULT 'DZD';
      ALTER TABLE orders ADD COLUMN billing_period TEXT NOT NULL DEFAULT '';
      ALTER TABLE orders ADD COLUMN product_id INTEGER;
      ALTER TABLE products ADD COLUMN price_amount INTEGER;
      ALTER TABLE products ADD COLUMN currency TEXT NOT NULL DEFAULT 'DZD';
      ALTER TABLE products ADD COLUMN billing_period TEXT NOT NULL DEFAULT 'شهرياً';
      ALTER TABLE products ADD COLUMN icon TEXT NOT NULL DEFAULT '◎';
    `
  }
];

function columnExists(table, column) {
  return db.prepare(`PRAGMA table_info(${table})`).all().some(row => row.name === column);
}
function runMigrations() {
  let current = db.pragma('user_version', { simple: true });
  for (const migration of migrations) {
    if (migration.version <= current) continue;
    const statements = migration.sql.split(';').map(s => s.trim()).filter(Boolean);
    const tx = db.transaction(() => {
      for (const statement of statements) {
        const alter = statement.match(/^ALTER TABLE (\w+) ADD COLUMN (\w+)/i);
        if (alter && columnExists(alter[1], alter[2])) continue;
        db.exec(statement);
      }
      db.pragma(`user_version = ${migration.version}`);
    });
    tx();
    current = migration.version;
  }
  // Legacy DBs may already have the columns added outside this migration.
  for (const [table, col, definition] of [
    ['orders','customer_contact',"TEXT NOT NULL DEFAULT ''"],
    ['orders','contact_channel',"TEXT NOT NULL DEFAULT ''"],
    ['orders','customer_message',"TEXT NOT NULL DEFAULT ''"],
    ['orders','price_amount','INTEGER'], ['orders','currency',"TEXT NOT NULL DEFAULT 'DZD'"],
    ['orders','billing_period',"TEXT NOT NULL DEFAULT ''"], ['orders','product_id','INTEGER'],
    ['products','price_amount','INTEGER'], ['products','currency',"TEXT NOT NULL DEFAULT 'DZD'"],
    ['products','billing_period',"TEXT NOT NULL DEFAULT 'شهرياً'"], ['products','icon',"TEXT NOT NULL DEFAULT '◎'"]
  ]) if (!columnExists(table, col)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${definition}`);
  db.exec(`CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
           CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at);
           CREATE INDEX IF NOT EXISTS idx_products_category_visible_sort ON products(category,visible,sort_order);`);
}
runMigrations();
// Normalize legacy SQLite datetime strings to explicit UTC ISO values.
db.exec(`UPDATE orders SET created_at=replace(created_at,' ','T')||'Z' WHERE created_at NOT LIKE '%Z' AND created_at LIKE '____-__-__ __:%';
         UPDATE orders SET updated_at=replace(updated_at,' ','T')||'Z' WHERE updated_at NOT LIKE '%Z' AND updated_at LIKE '____-__-__ __:%';`);
// Preserve duplicate legacy plans but give subsequent copies distinct labels before enforcing uniqueness.
for (const group of db.prepare('SELECT category,name,GROUP_CONCAT(id) ids FROM products GROUP BY category,name HAVING COUNT(*)>1').all()) {
  const ids=group.ids.split(',').map(Number).sort((a,b)=>a-b);
  for (const id of ids.slice(1)) db.prepare('UPDATE products SET name=? WHERE id=?').run(`${group.name} (نسخة ${id})`, id);
}
db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_products_category_name_unique ON products(category,name)');
for (const product of db.prepare('SELECT id,price FROM products WHERE price_amount IS NULL').all()) {
  const match=String(product.price).match(/[0-9]+/);
  if(match) db.prepare('UPDATE products SET price_amount=? WHERE id=?').run(Number(match[0]), product.id);
}

const defaultSettings = {
  whatsapp: '', instagram: '9vsrz', telegram: 'abdoouxy',
  siteTitle: 'Abdooux Marketplace', heroTitle: 'حضورك الرقمي، بخطوة أذكى.',
  heroTitleFirst: 'حضورك الرقمي،', heroTitleAccent: 'بخطوة أذكى.',
  heroDescription: 'اكتشف باقات وخدمات رقمية مختارة، قارن التفاصيل بوضوح، وأرسل طلبك خلال دقائق عبر مساعد الطلب التفاعلي.',
  logoUrl: '', currency: 'د.ج', currencySuffix: ' / شهرياً'
};
const insertSetting = db.prepare('INSERT OR IGNORE INTO site_settings(key,value) VALUES(?,?)');
for (const [key, value] of Object.entries(defaultSettings)) insertSetting.run(key, String(value));

const productCount = db.prepare('SELECT COUNT(*) AS n FROM products').get().n;
if (!productCount) {
  const defaults = [
    ['verified','Standard','300 د.ج','الأساسيات لحضور أكثر موثوقية.','حماية العلامة التجارية\nالحماية ضد انتحال الشخصية\nدعم عبر البريد الإلكتروني\nمزايا تحسين الظهور\nتحسين البحث',1,0,1],
    ['verified','Plus','400 د.ج','مزايا إضافية ودعم أكثر.','كل مزايا Standard\nحل المشكلات بسرعة أكبر\nطلب مكالمة من وكيل\nملف شخصي مميز\nرابطان للريلز شهرياً',1,0,2],
    ['verified','Premium','500 د.ج','توازن بين المزايا والدعم.','كل مزايا Plus\nدعم عبر قنوات إضافية\nمراقبة نشطة للحالات\nملصقات حصرية\n4 روابط ريلز شهرياً',1,1,3],
    ['verified','Max','600 د.ج','مجموعة مزايا موسّعة.','حماية متقدمة من الانتحال\nدعم محسّن متقدم\nدردشة أو بريد\nمتابعة الحالات\n6 روابط ريلز شهرياً',1,0,4],
    ['meta-one','Essential','600 د.ج','ابدأ بتأسيس حضور نشاطك.','شارة التحقق، وفق الأهلية\nالحماية ضد انتحال الشخصية\nصفحة الرابط',1,0,1],
    ['meta-one','Advanced','700 د.ج','أدوات ورؤى إضافية.','كل مزايا Essential\n4 روابط في المنشورات شهرياً\nرؤى تنافسية\nحالة دعم بشري شهرياً',1,0,2],
    ['meta-one','Expert','800 د.ج','مزايا أكثر لنشاطك التجاري.','كل مزايا Advanced\nاستخدام موسّع لأدوات AI\n8 روابط ريلز شهرياً\n5 حالات دعم بشري',1,1,3],
    ['meta-one','Max','1000 د.ج','مجموعة موسّعة من المزايا.','كل مزايا Expert\n12 رابطاً في المنشورات شهرياً\nدعم ومتابعة موسّعة',1,0,4],
    ['plus-apps','Instagram Plus','300 د.ج','اشتراك Instagram Plus','',1,0,1],
    ['plus-apps','Facebook Plus','300 د.ج','اشتراك Facebook Plus','',1,0,2],
    ['plus-apps','WhatsApp Plus','300 د.ج','اشتراك WhatsApp Plus','',1,0,3],
    ['support','استفسار عام','حسب الطلب','اطرح سؤالك وسنتواصل معك.','',1,0,1]
  ];
  const ins = db.prepare('INSERT INTO products(category,name,price,description,features,visible,featured,sort_order) VALUES(?,?,?,?,?,?,?,?)');
  db.transaction(rows => rows.forEach(row => ins.run(...row)))(defaults);
}
if (!db.prepare('SELECT COUNT(*) AS n FROM services').get().n) {
  const ins = db.prepare('INSERT INTO services(title,description,icon,visible,sort_order) VALUES(?,?,?,?,?)');
  [['مساعدة التوثيق','التعرّف على متطلبات وخيارات التوثيق المتاحة لحسابك.','◈',1,1],['إرشادات حماية الحساب','خطوات عملية لتحسين أمان الحساب والحد من انتحال الشخصية.','⌑',1,2],['تحسين الحضور','مساعدة في فهم أدوات الظهور وإدارة الملف الشخصي.','↗',1,3],['مساندة تقنية','تنظيم طلبك وتوجيهك إلى قناة التواصل المناسبة.','⌘',1,4]].forEach(row => ins.run(...row));
}
// Add the expanded service catalogue to existing databases without duplicating entries.
const additionalServices = [
  ['إعداد الملف الشخصي','مساعدة في ترتيب معلومات الملف والصورة والوصف بما يناسب نشاطك.','▧',1,5],
  ['تصميم محتوى بصري','تنسيق أفكارك وتوجيهك لطلب تصاميم مناسبة لهوية حسابك.','✧',1,6],
  ['إرشاد الاشتراكات','مقارنة الخيارات المتاحة وشرح المزايا والأسعار قبل الطلب.','⌁',1,7],
  ['مساعدة ما بعد الطلب','متابعة الحالة والإجابة عن الاستفسارات المتعلقة بطلبك.','◎',1,8]
];
const insertService = db.prepare('INSERT INTO services(title,description,icon,visible,sort_order) VALUES(?,?,?,?,?)');
for (const service of additionalServices) {
  if (!db.prepare('SELECT id FROM services WHERE title=? LIMIT 1').get(service[0])) insertService.run(...service);
}


// Create the first admin only. Existing credentials are never overwritten at boot.
const dummyHash = bcrypt.hashSync('not-a-real-password-for-timing-only', 12);
let admin = db.prepare('SELECT id,username FROM admins ORDER BY id LIMIT 1').get();
if (!admin) {
  const hash = bcrypt.hashSync(ADMIN_PASSWORD, 12);
  const result = db.prepare('INSERT INTO admins(username,password_hash) VALUES(?,?)').run(ADMIN_USERNAME, hash);
  admin = { id: result.lastInsertRowid, username: ADMIN_USERNAME };
} else if (process.env.ADMIN_RESET_PASSWORD === 'true') {
  const hash = bcrypt.hashSync(ADMIN_PASSWORD, 12);
  db.prepare('UPDATE admins SET username=?, password_hash=? WHERE id=?').run(ADMIN_USERNAME, hash, admin.id);
  admin = { id: admin.id, username: ADMIN_USERNAME };
}

// express-session Store implemented on the existing better-sqlite3 database.
class BetterSqliteSessionStore extends session.Store {
  get(sid, callback) {
    try {
      const row = db.prepare('SELECT sess,expired FROM sessions WHERE sid=?').get(sid);
      if (!row || row.expired <= Date.now()) return callback(null, null);
      callback(null, JSON.parse(row.sess));
    } catch (error) { callback(error); }
  }
  set(sid, sess, callback = () => {}) {
    try {
      const expired = sess.cookie?.expires ? new Date(sess.cookie.expires).getTime() : Date.now() + 86400000;
      db.prepare('INSERT INTO sessions(sid,sess,expired) VALUES(?,?,?) ON CONFLICT(sid) DO UPDATE SET sess=excluded.sess,expired=excluded.expired')
        .run(sid, JSON.stringify(sess), expired);
      callback();
    } catch (error) { callback(error); }
  }
  destroy(sid, callback = () => {}) {
    try { db.prepare('DELETE FROM sessions WHERE sid=?').run(sid); callback(); }
    catch (error) { callback(error); }
  }
  touch(sid, sess, callback = () => {}) { this.set(sid, sess, callback); }
}

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"], baseUri: ["'self'"], objectSrc: ["'none'"], frameAncestors: ["'none'"],
      // Inline code remains temporarily for backwards compatibility; extract it in the UI refactor before removing unsafe-inline.
      scriptSrc: ["'self'", "'unsafe-inline'"], styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'], imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'"], formAction: ["'self'"]
    }
  },
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  hsts: IS_PROD ? { maxAge: 31536000, includeSubDomains: true, preload: true } : false
}));
app.use((req, res, next) => {
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});
app.use(express.json({ limit: '2mb', strict: true }));
app.use(session({
  name: 'abdooux.sid', store: new BetterSqliteSessionStore(), secret: SESSION_SECRET,
  resave: false, saveUninitialized: false, rolling: true,
  cookie: { httpOnly: true, sameSite: 'lax', secure: IS_PROD, maxAge: 8 * 60 * 60 * 1000, path: '/' }
}));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, skipSuccessfulRequests: true, standardHeaders: 'draft-7', legacyHeaders: false });
const loginFailures = new Map();
function loginLockKey(username, ip) { return `${String(username).toLowerCase().slice(0,80)}|${ip}`; }
const orderLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 15, standardHeaders: 'draft-7', legacyHeaders: false });
const trackLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 40, standardHeaders: 'draft-7', legacyHeaders: false });
const adminLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 180, standardHeaders: 'draft-7', legacyHeaders: false });
app.use('/api/admin', adminLimiter);

function sameOriginMutation(req, res, next) {
  if (!['POST','PUT','PATCH','DELETE'].includes(req.method)) return next();
  const source = req.get('origin') || req.get('referer');
  if (!source) return res.status(403).json({ error: 'تعذر التحقق من مصدر الطلب. أعد تحميل الصفحة وحاول مجدداً.' });
  try {
    if (new URL(source).host !== req.get('host')) return res.status(403).json({ error: 'مصدر الطلب غير مسموح.' });
  } catch { return res.status(403).json({ error: 'مصدر الطلب غير صالح.' }); }
  next();
}
app.use('/api', sameOriginMutation);

const requireAdmin = (req, res, next) => req.session?.adminId
  ? next() : res.status(401).json({ error: 'انتهت الجلسة أو يجب تسجيل دخول المدير أولاً' });
const allowedCategories = new Set(['verified','meta-one','plus-apps','support']);
const clean = (value, max) => String(value ?? '').trim().slice(0, max);
const makeCode = () => { const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let out=''; const bytes=crypto.randomBytes(12); for(const byte of bytes) out+=alphabet[byte%alphabet.length]; return 'ABX-'+out; };
const audit = (req, action, type, id = '') => db.prepare('INSERT INTO admin_audit(admin_id,action,entity_type,entity_id) VALUES(?,?,?,?)').run(req.session.adminId, action, type, String(id));
function normalizeWhatsApp(value) {
  const digits = String(value || '').replace(/[+\s()-]/g, '');
  return /^\d{8,15}$/.test(digits) ? digits : '';
}
function categoryLabel(category) {
  return ({ verified: 'Meta Verified', 'meta-one': 'Meta One', 'plus-apps': 'اشتراكات Plus', support: 'خدمات أخرى' })[category] || '';
}

app.get('/healthz', (req, res) => res.status(200).json({ ok: true, database: db.open, timestamp: new Date().toISOString() }));
app.get('/api/site-config', rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false }), (req, res) => {
  res.setHeader('Cache-Control', 'public, max-age=30, stale-while-revalidate=60');
  const settings = Object.fromEntries(db.prepare('SELECT key,value FROM site_settings').all().map(row => [row.key, row.value]));
  settings.whatsapp = normalizeWhatsApp(settings.whatsapp);
  const products = db.prepare('SELECT id,category,name,price,description,features,visible,featured,sort_order,price_amount,currency,billing_period,icon FROM products WHERE visible=1 ORDER BY sort_order,id').all();
  const services = db.prepare('SELECT id,title,description,icon,visible,sort_order FROM services WHERE visible=1 ORDER BY sort_order,id').all();
  res.json({ settings, products, services });
});

app.post('/api/orders', orderLimiter, (req, res) => {
  const body = req.body || {};
  if (clean(body.website, 100) || Number(body.formDurationMs) < 1800) return res.status(400).json({ error: 'تعذر التحقق من الطلب.' }); // honeypot + minimum completion time
  const category = clean(body.category, 30);
  const plan = clean(body.plan, 80);
  const customerName = clean(body.customerName, 60);
  const accountLink = clean(body.accountLink, 160);
  const note = clean(body.note, 220);
  const contact = clean(body.customerContact, 80);
  const channel = clean(body.contactChannel, 20);
  const activeProduct = db.prepare('SELECT id,price,price_amount,currency,billing_period FROM products WHERE category=? AND name=? AND visible=1').get(category, plan);
  if (!allowedCategories.has(category) || !activeProduct || !customerName || customerName.length < 2 || !contact || contact.length < 3) return res.status(400).json({ error: 'تحقق من بيانات الطلب والباقة المختارة.' });
  if (accountLink && !/^@?[\w.]{2,60}$/.test(accountLink) && !/^https:\/\/(www\.)?(instagram\.com|facebook\.com|fb\.com|threads\.net)\/[\w./?=&%-]+$/i.test(accountLink)) return res.status(400).json({ error: 'رابط الحساب أو اسم المستخدم غير صالح.' });
  if (!/^(?:\+?\d[\d\s()-]{6,20}|@?[A-Za-z0-9._-]{3,40})$/.test(contact)) return res.status(400).json({ error: 'أدخل رقم هاتف أو معرّف تواصل صالحاً.' });
  if (!['whatsapp','instagram','telegram'].includes(channel)) return res.status(400).json({ error: 'قناة التواصل غير صالحة.' });
  // Avoid accidental duplicate submissions for the same customer and plan within 90 seconds.
  const duplicate = db.prepare(`SELECT tracking_code FROM orders WHERE customer_name=? AND category=? AND plan=? AND created_at >= strftime('%Y-%m-%dT%H:%M:%fZ','now','-90 seconds') ORDER BY id DESC LIMIT 1`).get(customerName, category, plan);
  if (duplicate) return res.status(409).json({ error: 'يوجد طلب حديث مماثل. استخدم رقم التتبع السابق بدلاً من إعادة الإرسال.', trackingCode: duplicate.tracking_code });
  let code;
  do { code = makeCode(); } while (db.prepare('SELECT 1 FROM orders WHERE tracking_code=?').get(code));
  const categoryName = categoryLabel(category);
  const info = db.prepare(`INSERT INTO orders
    (tracking_code,category,category_name,plan,price,customer_name,account_link,note,customer_contact,contact_channel,price_amount,currency,billing_period,product_id)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(code, category, categoryName, plan, activeProduct.price, customerName, accountLink, note, contact, channel, activeProduct.price_amount, activeProduct.currency || 'DZD', activeProduct.billing_period || '', activeProduct.id);
  db.prepare('INSERT INTO order_events(order_id,from_status,to_status,actor,note) VALUES(?,NULL,?,?,?)').run(info.lastInsertRowid, 'received', 'customer', 'تم استلام الطلب');
  res.status(201).json({ id: info.lastInsertRowid, trackingCode: code, status: 'received' });
});

app.get('/api/track/:code', trackLimiter, (req, res) => {
  const code = clean(req.params.code, 24).toUpperCase();
  const row = db.prepare(`SELECT tracking_code,category_name,plan,price,status,created_at,updated_at,customer_message
    FROM orders WHERE tracking_code=?`).get(code);
  if (!row) return res.status(404).json({ error: 'لم نعثر على طلب بهذا الرقم.' });
  const events = db.prepare('SELECT from_status,to_status,note,created_at FROM order_events WHERE order_id=(SELECT id FROM orders WHERE tracking_code=?) ORDER BY id').all(code);
  res.json({ order: row, events });
});

app.post('/api/login', loginLimiter, async (req, res) => {
  const username = clean(req.body?.username, 80);
  const password = String(req.body?.password || '');
  const lockKey = loginLockKey(username, req.ip);
  const lock = loginFailures.get(lockKey);
  if (lock && lock.until > Date.now()) return res.status(429).json({ error: 'محاولات كثيرة. انتظر قليلاً ثم حاول مجدداً.' });
  const found = db.prepare('SELECT * FROM admins WHERE username=?').get(username);
  const valid = await bcrypt.compare(password, found?.password_hash || dummyHash);
  if (!found || !valid) { const attempts=(lock?.attempts||0)+1; const delay=attempts>=5?Math.min(15*60*1000,30000*Math.pow(2,Math.min(attempts-5,4))):0; loginFailures.set(lockKey,{attempts,until:Date.now()+delay}); return res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غير صحيحة.' }); }
  loginFailures.delete(lockKey);
  if (bcrypt.getRounds(found.password_hash) < 12) db.prepare('UPDATE admins SET password_hash=? WHERE id=?').run(await bcrypt.hash(password, 12), found.id);
  req.session.regenerate(error => {
    if (error) return res.status(500).json({ error: 'تعذر إنشاء جلسة الدخول.' });
    req.session.adminId = found.id;
    req.session.username = found.username;
    req.session.save(saveError => saveError ? res.status(500).json({ error: 'تعذر حفظ جلسة الدخول.' }) : res.json({ ok: true, username: found.username }));
  });
});
app.get('/api/me', requireAdmin, (req, res) => res.json({ username: req.session.username }));
app.post('/api/logout', requireAdmin, (req, res, next) => {
  const cookieOptions = { path: '/', httpOnly: true, sameSite: 'lax', secure: IS_PROD };
  req.session.destroy(error => {
    if (error) return next(error);
    res.clearCookie('abdooux.sid', cookieOptions);
    res.json({ ok: true });
  });
});
app.post('/api/admin/logout-all', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM sessions').run();
  res.clearCookie('abdooux.sid', { path: '/', httpOnly: true, sameSite: 'lax', secure: IS_PROD });
  res.json({ ok: true });
});
app.put('/api/admin/password', requireAdmin, async (req, res) => {
  const currentPassword = String(req.body?.currentPassword || '');
  const newPassword = String(req.body?.newPassword || '');
  const row = db.prepare('SELECT password_hash FROM admins WHERE id=?').get(req.session.adminId);
  if (!row || !(await bcrypt.compare(currentPassword, row.password_hash))) return res.status(400).json({ error: 'كلمة المرور الحالية غير صحيحة.' });
  if (newPassword.length < 12 || newPassword.length > 200) return res.status(400).json({ error: 'يجب أن تتكون كلمة المرور الجديدة من 12 حرفاً على الأقل.' });
  db.prepare('UPDATE admins SET password_hash=? WHERE id=?').run(await bcrypt.hash(newPassword, 12), req.session.adminId);
  db.prepare('DELETE FROM sessions WHERE sid<>?').run(req.sessionID);
  audit(req, 'change_password', 'admin', req.session.adminId);
  res.json({ ok: true });
});

app.get('/api/admin/stats', requireAdmin, (req, res) => {
  const count = status => db.prepare('SELECT COUNT(*) AS n FROM orders WHERE status=?').get(status).n;
  const total = db.prepare('SELECT COUNT(*) AS n FROM orders').get().n;
  res.json({ total, received: count('received'), processing: count('processing'), completed: count('completed'), cancelled: count('cancelled') });
});
app.get('/api/admin/orders', requireAdmin, (req, res) => {
  const rows = db.prepare(`SELECT id,tracking_code,category_name,plan,price,customer_name,account_link,note,status,admin_note,customer_message,customer_contact,contact_channel,created_at,updated_at FROM orders ORDER BY id DESC LIMIT 300`).all();
  res.json({ orders: rows });
});
app.get('/api/admin/export.csv', requireAdmin, (req, res) => {
  const rows = db.prepare(`SELECT tracking_code,customer_name,customer_contact,contact_channel,category_name,plan,price,status,account_link,note,admin_note,customer_message,created_at,updated_at FROM orders ORDER BY id DESC`).all();
  const headers = ['tracking_code','customer_name','customer_contact','contact_channel','category','plan','price','status','account_link','customer_note','admin_note','customer_message','created_at','updated_at'];
  const csvCell = value => { let v = String(value ?? ''); if (/^[=+@\-\t\r]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; };
  const csv = '\uFEFF' + [headers.join(','), ...rows.map(row => [row.tracking_code,row.customer_name,row.customer_contact,row.contact_channel,row.category_name,row.plan,row.price,row.status,row.account_link,row.note,row.admin_note,row.customer_message,row.created_at,row.updated_at].map(csvCell).join(','))].join('\r\n');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="abdooux-orders.csv"');
  res.setHeader('Cache-Control', 'no-store');
  res.send(csv);
});
app.patch('/api/admin/orders/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const status = clean(req.body?.status, 20);
  const adminNote = clean(req.body?.adminNote, 300);
  const customerMessage = clean(req.body?.customerMessage, 500);
  if (!Number.isInteger(id) || !['received','processing','completed','cancelled'].includes(status)) return res.status(400).json({ error: 'بيانات التحديث غير صالحة.' });
  const old = db.prepare('SELECT status FROM orders WHERE id=?').get(id);
  if (!old) return res.status(404).json({ error: 'الطلب غير موجود.' });
  const tx = db.transaction(() => {
    db.prepare(`UPDATE orders SET status=?,admin_note=?,customer_message=?,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?`).run(status, adminNote, customerMessage, id);
    if (old.status !== status) db.prepare('INSERT INTO order_events(order_id,from_status,to_status,actor,note) VALUES(?,?,?,?,?)').run(id, old.status, status, req.session.username, adminNote);
  });
  tx(); audit(req, 'update_order', 'order', id);
  res.json({ ok: true });
});
app.delete('/api/admin/orders/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: 'رقم الطلب غير صالح.' });
  const result = db.prepare('DELETE FROM orders WHERE id=?').run(id);
  if (!result.changes) return res.status(404).json({ error: 'الطلب غير موجود.' });
  audit(req, 'delete_order', 'order', id);
  res.json({ ok: true });
});

app.get('/api/admin/config', requireAdmin, (req, res) => {
  const settings = Object.fromEntries(db.prepare('SELECT key,value FROM site_settings').all().map(row => [row.key, row.value]));
  res.json({ settings, products: db.prepare('SELECT * FROM products ORDER BY category,sort_order,id').all(), services: db.prepare('SELECT * FROM services ORDER BY sort_order,id').all() });
});
app.put('/api/admin/settings', requireAdmin, (req, res) => {
  const allowed = new Set([...Object.keys(defaultSettings), 'heroTitleFirst', 'heroTitleAccent']);
  const stmt = db.prepare('INSERT INTO site_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
  const entries = Object.entries(req.body || {});
  for (const [key, value] of entries) {
    if (!allowed.has(key) || typeof value !== 'string' || value.length > 500) return res.status(400).json({ error: 'إحدى الإعدادات غير صالحة.' });
  }
  if (Object.prototype.hasOwnProperty.call(req.body || {}, 'whatsapp') && String(req.body.whatsapp || '').trim() && !normalizeWhatsApp(req.body.whatsapp)) return res.status(400).json({ error: 'رقم واتساب يجب أن يكون بصيغة دولية ويتكون من 8 إلى 15 رقماً.' });
  const normalized = entries.map(([key, value]) => [key, key === 'whatsapp' ? normalizeWhatsApp(value) : clean(value, 500)]);
  db.transaction(rows => rows.forEach(([key, value]) => stmt.run(key, value)))(normalized);
  audit(req, 'update_settings', 'settings');
  res.json({ ok: true });
});
app.post('/api/admin/products', requireAdmin, (req, res) => {
  const b = req.body || {};
  const category = clean(b.category, 30), name = clean(b.name, 80), price = clean(b.price, 40);
  if (!allowedCategories.has(category) || !name || !price) return res.status(400).json({ error: 'أدخل القسم واسم الباقة والسعر.' });
  if (db.prepare('SELECT 1 FROM products WHERE category=? AND name=?').get(category, name)) return res.status(409).json({ error: 'توجد باقة بهذا الاسم في القسم نفسه.' });
  const result = db.prepare('INSERT INTO products(category,name,price,description,features,visible,featured,sort_order,price_amount,currency,billing_period,icon) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)')
    .run(category, name, price, clean(b.description, 240), clean(b.features, 1200), b.visible === false ? 0 : 1, b.featured ? 1 : 0, Number.isFinite(Number(b.sort_order)) ? Number(b.sort_order) : 0, b.price_amount !== null && b.price_amount !== undefined && b.price_amount !== '' && Number.isSafeInteger(Number(b.price_amount)) && Number(b.price_amount) >= 0 ? Number(b.price_amount) : null, clean(b.currency, 8) || 'DZD', clean(b.billing_period, 40), clean(b.icon, 8) || '◎');
  audit(req, 'create_product', 'product', result.lastInsertRowid);
  res.status(201).json({ id: result.lastInsertRowid });
});
app.put('/api/admin/products/:id', requireAdmin, (req, res) => {
  const b = req.body || {}, id = Number(req.params.id), category = clean(b.category, 30), name = clean(b.name, 80), price = clean(b.price, 40);
  if (!Number.isInteger(id) || !allowedCategories.has(category) || !name || !price) return res.status(400).json({ error: 'بيانات الباقة غير صالحة.' });
  if (db.prepare('SELECT 1 FROM products WHERE category=? AND name=? AND id<>?').get(category, name, id)) return res.status(409).json({ error: 'توجد باقة بهذا الاسم في القسم نفسه.' });
  const result = db.prepare('UPDATE products SET category=?,name=?,price=?,description=?,features=?,visible=?,featured=?,sort_order=?,price_amount=?,currency=?,billing_period=?,icon=? WHERE id=?')
    .run(category, name, price, clean(b.description, 240), clean(b.features, 1200), b.visible ? 1 : 0, b.featured ? 1 : 0, Number.isFinite(Number(b.sort_order)) ? Number(b.sort_order) : 0, b.price_amount !== null && b.price_amount !== undefined && b.price_amount !== '' && Number.isSafeInteger(Number(b.price_amount)) && Number(b.price_amount) >= 0 ? Number(b.price_amount) : null, clean(b.currency, 8) || 'DZD', clean(b.billing_period, 40), clean(b.icon, 8) || '◎', id);
  if (!result.changes) return res.status(404).json({ error: 'الباقة غير موجودة.' });
  audit(req, 'update_product', 'product', id); res.json({ ok: true });
});
app.delete('/api/admin/products/:id', requireAdmin, (req, res) => { const id=Number(req.params.id); const result=db.prepare('DELETE FROM products WHERE id=?').run(id); if(!result.changes)return res.status(404).json({error:'الباقة غير موجودة.'}); audit(req,'delete_product','product',id); res.json({ok:true}); });
app.post('/api/admin/services', requireAdmin, (req, res) => { const b=req.body||{}, title=clean(b.title,100); if(!title)return res.status(400).json({error:'اسم الخدمة مطلوب.'}); const r=db.prepare('INSERT INTO services(title,description,icon,visible,sort_order) VALUES(?,?,?,?,?)').run(title,clean(b.description,300),clean(b.icon,8)||'✦',b.visible===false?0:1,Number(b.sort_order)||0); audit(req,'create_service','service',r.lastInsertRowid); res.status(201).json({id:r.lastInsertRowid}); });
app.put('/api/admin/services/:id', requireAdmin, (req, res) => { const b=req.body||{},id=Number(req.params.id),title=clean(b.title,100); if(!Number.isInteger(id)||!title)return res.status(400).json({error:'بيانات الخدمة غير صالحة.'}); const r=db.prepare('UPDATE services SET title=?,description=?,icon=?,visible=?,sort_order=? WHERE id=?').run(title,clean(b.description,300),clean(b.icon,8)||'✦',b.visible?1:0,Number.isFinite(Number(b.sort_order))?Number(b.sort_order):0,id); if(!r.changes)return res.status(404).json({error:'الخدمة غير موجودة.'}); audit(req,'update_service','service',id); res.json({ok:true}); });
app.delete('/api/admin/services/:id', requireAdmin, (req, res) => { const id=Number(req.params.id),r=db.prepare('DELETE FROM services WHERE id=?').run(id); if(!r.changes)return res.status(404).json({error:'الخدمة غير موجودة.'}); audit(req,'delete_service','service',id); res.json({ok:true}); });

app.post('/api/admin/logo', requireAdmin, (req, res) => {
  const dataUrl = String(req.body?.dataUrl || '');
  const match = dataUrl.match(/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/);
  if (!match) return res.status(400).json({ error: 'اختر صورة PNG أو JPG أو WebP أو SVG صالحة.' });
  const buffer = Buffer.from(match[2], 'base64');
  if (!buffer.length || buffer.length > 1024 * 1024) return res.status(400).json({ error: 'حجم الشعار يجب ألا يتجاوز 1 ميغابايت.' });
  const validSignature = match[1] === 'png' ? buffer.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])) : match[1] === 'jpeg' ? buffer[0]===0xff && buffer[1]===0xd8 && buffer[2]===0xff : buffer.toString('ascii',0,4)==='RIFF' && buffer.toString('ascii',8,12)==='WEBP';
  if (!validSignature) return res.status(400).json({ error: 'محتوى الصورة لا يطابق نوع الملف.' });
  const ext = ({ png: 'png', jpeg: 'jpg', webp: 'webp' })[match[1]];
  const uploadDir = path.join(DATA_DIR, 'uploads');
  fs.mkdirSync(uploadDir, { recursive: true });
  const fileName = `site-logo-${crypto.randomBytes(6).toString('hex')}.${ext}`;
  fs.writeFileSync(path.join(uploadDir, fileName), buffer, { flag: 'wx' });
  const logoUrl = `/uploads/${fileName}`;
  db.prepare('INSERT INTO site_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run('logoUrl', logoUrl);
  audit(req, 'update_logo', 'settings', fileName);
  res.json({ ok: true, logoUrl });
});

async function createBackup() {
  const backupDir = path.join(DATA_DIR, 'backups');
  fs.mkdirSync(backupDir, { recursive: true });
  const file = path.join(backupDir, `marketplace-${new Date().toISOString().replace(/[:.]/g,'-')}.sqlite`);
  await db.backup(file);
  const uploads = path.join(DATA_DIR, 'uploads');
  if (fs.existsSync(uploads)) { const assets = path.join(backupDir, path.basename(file, '.sqlite') + '-assets'); fs.mkdirSync(assets, { recursive: true }); for (const name of fs.readdirSync(uploads)) { if (/^site-logo-[a-f0-9]{12}\.(png|jpg|webp)$/.test(name)) fs.copyFileSync(path.join(uploads, name), path.join(assets, name)); } }
  const oldFiles = fs.readdirSync(backupDir).filter(name => name.endsWith('.sqlite')).sort().reverse();
  for (const old of oldFiles.slice(10)) { fs.unlinkSync(path.join(backupDir, old)); const assets=path.join(backupDir, old.replace(/\.sqlite$/, '-assets')); if(fs.existsSync(assets)) fs.rmSync(assets,{recursive:true,force:true}); }
  return file;
}
app.get('/api/admin/backup', requireAdmin, async (req, res, next) => {
  try { const file = await createBackup(); res.download(file, path.basename(file), error => { if (error) next(error); }); }
  catch (error) { next(error); }
});

app.get('/uploads/:name', (req, res) => {
  const name = String(req.params.name || '');
  if (!/^site-logo-[a-f0-9]{12}\.(png|jpg|webp)$/.test(name)) return res.status(404).end();
  res.setHeader('Cache-Control', 'public, max-age=86400, immutable');
  res.sendFile(path.join(DATA_DIR, 'uploads', name), error => { if (error && !res.headersSent) res.status(404).end(); });
});
app.use(express.static(path.join(__dirname, 'public'), { etag: true, maxAge: IS_PROD ? '1h' : 0 }));
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));
app.get('/track', (req, res) => res.sendFile(path.join(__dirname, 'public', 'track.html')));
app.use((req, res) => res.status(404).send('الصفحة المطلوبة غير موجودة.'));
app.use((error, req, res, next) => {
  if (res.headersSent) return next(error);
  if (error instanceof SyntaxError && error.status === 400 && 'body' in error) return res.status(400).json({ error: 'صيغة البيانات المرسلة غير صالحة.' });
  console.error('[request-error]', error.message);
  res.status(500).json({ error: 'حدث خطأ داخلي. حاول مجدداً لاحقاً.' });
});

const server = app.listen(PORT, () => console.log(`Abdooux Marketplace listening on ${PORT}`));
const scheduledBackup = setInterval(() => createBackup().catch(error => console.error('[backup-error]', error.message)), 24 * 60 * 60 * 1000);
scheduledBackup.unref();
let shuttingDown = false;
function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`[shutdown] ${signal}`);
  clearInterval(scheduledBackup);
  server.close(() => { try { db.pragma('wal_checkpoint(TRUNCATE)'); db.close(); } finally { process.exit(0); } });
  setTimeout(() => process.exit(1), 10000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('unhandledRejection', error => console.error('[unhandledRejection]', error));
